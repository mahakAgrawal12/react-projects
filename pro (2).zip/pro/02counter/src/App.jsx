import { useState} from 'react'
import './App.css'

function App() {
  const [count, setCount] = useState(0)
  let[counter, setCounter] = useState(5);
  
// let counter =5
const addValue=()=>{
  // console.log('add value',counter);
  (counter >= 20) ? setCounter(counter) :
  setCounter(counter + 1);
}

const removeValue=()=>{
  (counter <= 0) ? setCounter(counter) :
  setCounter(counter - 1);
}
  return (
    <>
     <h1> react</h1>
     <h2>counter value: {counter}</h2>
     <button onClick={addValue}>Add value</button>
     <br/>
     <button onClick={removeValue}>remove value</button>


    </>
  )
}

export default App
