import { useState,useEffect } from 'react'
import './App.css'
import axios from 'axios'


function App() {
  const [jokes, setjokes] = useState([])
  useEffect(() => {
    axios.get('/api/jokes')
    .then((res) => {
      setjokes(res.data)
    })
    .catch((err)=>{
      console.log(err)
    })
  })

  return (
    <>
      <h1>full stack</h1>
      <p>Jokes: {jokes.length}</p>
      {
        jokes.map((joke,index) => 
          (
            <div key={jokes.id}>
              <h2>{joke.title}</h2>
              <p>{joke.content}</p>
            </div>
          )
        )
      }
    </>
  )
}

export default App
