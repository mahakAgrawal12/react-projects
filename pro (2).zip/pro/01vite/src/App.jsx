import Chai from "./chai"


function App() {
 
const username = "John Doe"
  return (
    <>
   <Chai />
   <h1>{username}</h1>
   </>
  )
}

export default App
