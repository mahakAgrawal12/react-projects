import express from 'express';

const app = express();
console.log('server is running');

app.get('/api/products', (req, res) => {

    const products =[
        {
            id:1,
            name: 'Nike Slim Shirt',
            price: 5000,
            image: '/images/p1.jpg'
        },
        {
            id:2,
            name: 'Adidas Fit Shirt',
            price :6000,
            image: '/images/p2.jpg'
        },
        {
            id:3,
            name: 'Lacoste Free Shirt',
            price :7000,
            image: '/images/p3.jpg'
        },
        {
            id:4,
            name: "Nike Slim Pant",
            price :8000,
            image: '/images/p4.jpg'
        },
        {
            id:5,
            name: 'Puma Slim Pant',
            price :9000,
            image: '/images/p5.jpg'
        }, 
    ]

    if(req.query.search){
       const filterProducts = products.filter(product => product.name.toLowerCase().includes(req.query.search.toLowerCase()));
       res.send(filterProducts);
       return;
       
    }


    setTimeout(() => {
        res.send(products);
    }, 3000);


});

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
})