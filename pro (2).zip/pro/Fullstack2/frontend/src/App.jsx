import { useEffect, useState } from 'react'
import './App.css'
import axios from 'axios'

function App() {
  // const [products,error,loading] = customReactQuery('/api/products')
  const [products, setProducts] = useState([])
  const[error,setError] = useState(false)
  const[loading,setLoading] = useState(false);
  const[search,setSearch] = useState('')

  useEffect(() => {
    const controller = new AbortController()
    ;(async()=>{
     try {
       setLoading(true);
       setError(false);
       const response = await axios.get('/api/products?search='+search,{signal:controller.signal});
       setProducts(response.data);
       console.log(JSON.stringify(response.data));
       setLoading(false);
     } catch (error) {
      if(axios.isCancel(error)){
        console.log(`Request was cancelled ${error}`);
        return;
      } 
       setError(true);
       console.log(error);
       setLoading(false);
     }
    }) ()
  // useEffect(() => {
  //   axios.get('/api/products?search='+search)
  //   .then((res)=>setProducts(res.data))
  //   // console.log(JSON.stringify(res)))
  //   .catch(err=>console.log(err))
   
  
  // })

    // cleanup code
    return ()=>{
      controller.abort();
    }
 },[search]);


// if(error){
//   return <h1>Something went wrong</h1>
// }
// if(loading){
//   return <h1>Loading...</h1>
// }



  return (
    <>
      <h1>axios</h1>
      <input type="text" placeholder="search" 
      value={search} onChange={(e)=>setSearch(e.target.value)}/>
      

       {loading && (<h1>Loading...</h1>)}
      {error && (<h1>Something went wrong</h1>)} 
     <h2> number of products are:{products.length}</h2> 
    </>
  )
}

export default App


// const customReactQuery = (urlPath) =>{
//   const [products, setProducts] = useState([])
//   const[error,setError] = useState(false)
//   const[loading,setLoading] = useState(false);

//   useEffect(() => {
//     (async()=>{
//      try {
//        setLoading(true);
//        setError(false);
//        const res = await axios.get(urlPath);
//        console.log(res.data);
//        setProducts(res.data);
//        setLoading(false);
//      } catch (error) {
//        setError(true);
//        console.log(error);
//        setLoading(false);
//      }
//     }) ()
//  },[])
//  return [products,error,loading]
// }
